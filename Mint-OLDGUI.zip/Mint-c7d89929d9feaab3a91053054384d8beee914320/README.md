# Mint 
- Main devs: zPrestige, Kambing
- Devs: FB, Zenov, gerald0mc

Notable features:
- Custom PopESP
- Custom CrystalAura
- Custom HoleFiller
- VClip Bypass

[Discord server Soon](https://discordserver.com/Mint!)

