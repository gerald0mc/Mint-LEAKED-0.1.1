package mint.events;

public class UpdateWalkingPlayerEvent extends EventProcessor {
    public UpdateWalkingPlayerEvent(int stage) {
        super(stage);
    }
}
