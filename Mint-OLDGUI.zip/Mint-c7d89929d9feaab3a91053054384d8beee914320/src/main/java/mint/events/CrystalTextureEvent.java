package mint.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class CrystalTextureEvent extends EventProcessor {

}
